

# Enable the virtual space options for both Scintilla views
# For more information, see the Scintilla documentation on virtual space and the SCI_SETVIRTUALSPACEOPTIONS message.

editor1.setVirtualSpaceOptions(3)
editor2.setVirtualSpaceOptions(3)
